// Theme persistence
const THEME_KEY = "portfolio_theme";
const themeBtn = document.querySelector("#themeToggle");
const navLinks = document.querySelector(".nav-links");
const burger = document.querySelector("#burger");

function applySavedTheme() {
  const saved = localStorage.getItem(THEME_KEY);
  if (saved === "light") {
    document.body.classList.add("light");
  } else {
    document.body.classList.remove("light"); // Default dark mode
  }
}
applySavedTheme();

function toggleTheme() {
  document.body.classList.toggle("light");
  localStorage.setItem(
    THEME_KEY,
    document.body.classList.contains("light") ? "light" : "dark"
  );
}
if (themeBtn) {
  themeBtn.addEventListener("click", toggleTheme);
}

// Mobile menu toggle
if (burger) {
  burger.addEventListener("click", () => {
    navLinks.classList.toggle("open");
  });
}
